package com.example.challenge.ForoHub.challenge.ForoHub.model;

public enum Curso {
    JAVA,
    WEB,
    BASES_DE_DATOS,
    ANGULAR,
    POO,
    ENSAMBLADOR,
    LOGICA_DE_PROGRAMACION
}
