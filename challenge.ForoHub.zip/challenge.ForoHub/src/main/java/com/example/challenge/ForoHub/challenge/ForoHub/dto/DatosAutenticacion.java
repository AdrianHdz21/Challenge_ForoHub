package com.example.challenge.ForoHub.challenge.ForoHub.dto;

public record DatosAutenticacion(String login, String password) {
}
