package com.example.challenge.ForoHub.challenge.ForoHub.dto;

public record DatosTokenJWT(String token) {
}
