package com.example.challenge.ForoHub.challenge.ForoHub.repository;

import com.example.challenge.ForoHub.challenge.ForoHub.model.Topico;
import org.springframework.data.jpa.repository.JpaRepository;


public interface TopicoRepository extends JpaRepository<Topico, Long> {
}
