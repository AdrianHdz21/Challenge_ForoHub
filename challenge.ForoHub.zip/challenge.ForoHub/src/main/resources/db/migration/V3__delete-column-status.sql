ALTER TABLE topicos DROP COLUMN status;
